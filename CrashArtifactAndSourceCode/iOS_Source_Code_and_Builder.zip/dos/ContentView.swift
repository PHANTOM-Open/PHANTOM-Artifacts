//
//  ContentView.swift
//  dos
//
//  Created by bubble on 4/26/25.
//

import SwiftUI
import WidgetKit

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
        .onAppear {
           WidgetCenter.shared.reloadAllTimelines()
           WidgetCenter.shared.reloadTimelines(ofKind: "myEvilWidget")
        }
    }
}

#Preview {
    ContentView()
}
