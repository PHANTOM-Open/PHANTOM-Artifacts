//
//  myEvilWidgetBundle.swift
//  myEvilWidget
//
//  Created by bubble on 5/2/25.
//

import WidgetKit
import SwiftUI


struct myEvilWidgetBundle: WidgetBundle {
    var body: some Widget {
        myEvilWidget()
        myEvilWidgetControl()
        myEvilWidgetLiveActivity()
    }
}

@main
struct VeryEvilWidgetEntryPoint {
    static func main() {
       WidgetCenter.shared.reloadAllTimelines()
       WidgetCenter.shared.reloadTimelines(ofKind: "myEvilWidget")
        myEvilWidgetBundle.main()
    }
}
