package com.security.dospackageinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Process;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "evil";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        PackageManager packageManager = getPackageManager();
        try {
            Log.e(TAG, "myUid: " + Process.myUid());
            PackageInfo packageInfo = packageManager.getPackageInfo(getPackageName(), PackageManager.GET_ACTIVITIES);
            Parcel parcel = Parcel.obtain();
            parcel.setDataPosition(0);
            (packageInfo).writeToParcel(parcel, 0);
            byte[] bytes = parcel.marshall();
            Log.e(TAG, "packageInfo.length: " + bytes.length);
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}