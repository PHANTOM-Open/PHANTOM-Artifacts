package com.security.dospackageinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Process;
import android.util.Log;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "evil";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        PackageManager packageManager = getPackageManager();
        try {
            Log.e(TAG, "myUid: " + Process.myUid());
            List<ResolveInfo> mediaServices = packageManager.queryIntentServices(new Intent("android.media.browse.MediaBrowserService"),
                    PackageManager.GET_RESOLVED_FILTER);
            List<ResolveInfo> resolveInfos = packageManager.queryIntentActivities(new Intent("evil"), PackageManager.GET_RESOLVED_FILTER);
            PackageInfo packageInfo = packageManager.getPackageInfo(getPackageName(), PackageManager.GET_ACTIVITIES|PackageManager.GET_SERVICES|PackageManager.GET_RECEIVERS|PackageManager.GET_PROVIDERS
                |PackageManager.GET_SIGNING_CERTIFICATES |PackageManager.GET_SIGNATURES|PackageManager.GET_SHARED_LIBRARY_FILES);
            Parcel parcel = Parcel.obtain();
            parcel.setDataPosition(0);
            (packageInfo.applicationInfo).writeToParcel(parcel, 0);
            byte[] bytes = parcel.marshall();
            Log.e(TAG, "packageInfo.length: " + bytes.length);
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}