import UIKit
import CoreSpotlight
import MobileCoreServices
import BackgroundTasks
import WidgetKit


class AppDelegate: NSObject, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        BGTaskScheduler.shared.register(
                forTaskWithIdentifier: "con.evil.dos",
                using: nil
            ) { task in
                // 处理回调
                self.handleAppRefresh(task: task as! BGAppRefreshTask)
            }
            return true
    }
    
    func application(_ application: UIApplication, performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
    }
    
    func handleAppRefresh(task: BGAppRefreshTask) {
        scheduleAppRefresh()

        WidgetCenter.shared.reloadAllTimelines()
        WidgetCenter.shared.reloadTimelines(ofKind: "myEvilWidget")
        task.setTaskCompleted(success: true)
    }
    
    func scheduleAppRefresh() {
        let request = BGAppRefreshTaskRequest(identifier: "con.evil.dos")
        request.earliestBeginDate = Date(timeIntervalSinceNow: 5)
        do {
            try BGTaskScheduler.shared.submit(request)
        } catch {
            print("Fail: \(error)")
        }
    }
    
}
    
