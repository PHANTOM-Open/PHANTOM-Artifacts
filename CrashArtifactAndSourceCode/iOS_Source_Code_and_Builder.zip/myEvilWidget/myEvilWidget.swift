//
//  myEvilWidget.swift
//  myEvilWidget
//
//  Created by bubble on 5/2/25.
//

import WidgetKit
import SwiftUI

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> SimpleEntry {
        fatalError("Crashing on placeholder generation")
        return SimpleEntry(date: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (SimpleEntry) -> ()) {
        fatalError("Crashing on snapshot generation")
        let entry = SimpleEntry(date: Date())
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
        var entries: [SimpleEntry] = []

        let currentDate = Date()
        for _ in 0..<50 {
            let entry = SimpleEntry(date: currentDate)
            entries.append(entry)
        }

        let timeline = Timeline(entries: entries, policy:.after(currentDate))
        completion(timeline)
        // Thread.sleep(forTimeInterval: 1)
        // fatalError("Crashing on timeline generation")
    }
}

struct SimpleEntry: TimelineEntry {
    let date: Date
}

struct myEvilWidgetEntryView : View {
    var entry: Provider.Entry
    @Environment(\.widgetFamily) var family

    var body: some View {
        switch family {
        case .accessoryCircular:
            // 锁屏圆形 Widget
            Text("😀")
                .font(.system(size: 40))
        case .accessoryRectangular:
            // 锁屏矩形 Widget
            VStack(alignment: .leading) {
                Text("时间: \(formattedTime(entry.date))")
                    .font(.caption)
                Text("😀")
                    .font(.title)
            }
        case .accessoryInline:
            // 锁屏内联 Widget
            Text("😀 \(formattedTime(entry.date))")
        default:
            // 主屏幕 Widget
            VStack {
                Text("Time:")
                Text(formattedTime(entry.date))
                
                Text("Favorite Emoji:")
                Text("😀")
            }
        }
    }
    
    // 格式化时间到秒级别
    private func formattedTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: date)
    }
}

struct myEvilWidget: Widget {
    let kind: String = "myEvilWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            myEvilWidgetEntryView(entry: entry)
                .containerBackground(.fill.tertiary, for: .widget)
        }
        .supportedFamilies([
            .systemSmall,
            .systemMedium,
            .systemLarge,
            .systemExtraLarge,
            .accessoryCircular,
            .accessoryRectangular,
            .accessoryInline
        ])
    }
}

#Preview(as: .systemSmall) {
    myEvilWidget()
} timeline: {
    SimpleEntry(date: .now)
}
