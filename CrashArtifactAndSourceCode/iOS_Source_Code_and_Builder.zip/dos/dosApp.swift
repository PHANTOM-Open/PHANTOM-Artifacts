//
//  dosApp.swift
//  dos
//
//  Created by bubble on 4/26/25.
//

import SwiftUI

@main
struct dosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
